#include <iostream>
#include <fstream>
#include <cmath>
#include <functional>
#include <string>
#include <cstdlib>

#include "RTP.h"
#include "RRT.h"
#include "RU.h"
#include "CollisionChecking.h"
#include <ompl/geometric/SimpleSetup.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/spaces/SO2StateSpace.h>
#include <ompl/base/spaces/SE2StateSpace.h>





// This is our state validitiy checker for checking if our point robot is in collision
bool isValidStatePoint(const ompl::base::State* state, const std::vector<Rectangle>& obstacles, ompl::base::RealVectorBounds bounds, int robots)
{
   const ompl::base::RealVectorStateSpace::StateType* r2state;
    r2state = state->as<ompl::base::RealVectorStateSpace::StateType>();
    // Extract x, y
	
     int *x =NULL; 
     x = new int[robots*2];
	
     for(int i=0 ; i< (robots*2);i++)

     { 
	
	*(x + i)= r2state->values[i];
	
     } 

      for(int i=0 ; i< (robots); i++)
      {
		int e =i*2; // even indicator, x
		int o =2*i+1; // odd indicator, y
  
  		if (x[e] > bounds.high[0] || x[e] < bounds.low[0] || x[o] > bounds.high[1] || x[o] < bounds.low[1])
      {		
      
	  return false;
      }  
      
	  return true; //isValidPoint(x, y, x1,y1, obstacles);  	
      }   

}


// This is our state validity checker for checking if our square robot is in collision
bool isValidStateSquare(const ompl::base::State* state, double sideLength, const std::vector<Rectangle>& obstacles, ompl::base::RealVectorBounds bounds)
{
    const ompl::base::CompoundState* cstate = state->as<ompl::base::CompoundState>();

    // Extract x, y, theta
    const ompl::base::RealVectorStateSpace::StateType* r2state = cstate->as<ompl::base::RealVectorStateSpace::StateType>(0);
    double x = r2state->values[0];
    double y = r2state->values[1];

    const ompl::base::SO2StateSpace::StateType* so2State = cstate->as<ompl::base::SO2StateSpace::StateType>(1);
    double theta = so2State->value;
    
    // rotate square
    double rot_bl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_bl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    double rot_br_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_br_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    double rot_tl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;
    double rot_tr_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tr_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;

    // check bounds
    if (rot_bl_x > bounds.high[0] || rot_bl_x < bounds.low[0] || rot_bl_y > bounds.high[1] || rot_bl_y < bounds.low[1])
    {
        return false;
    }
    if (rot_br_x > bounds.high[0] || rot_br_x < bounds.low[0] || rot_br_y > bounds.high[1] || rot_br_y < bounds.low[1])
    {
        return false;
    }
    if (rot_tl_x > bounds.high[0] || rot_tl_x < bounds.low[0] || rot_tl_y > bounds.high[1] || rot_tl_y < bounds.low[1])
    {
        return false;
    }
    if (rot_tr_x > bounds.high[0] || rot_tr_x < bounds.low[0] || rot_tr_y > bounds.high[1] || rot_tr_y < bounds.low[1])
    {
        return false;
    }

    return isValidSquare(x, y, theta, sideLength, obstacles);
}

void planWithSimpleSetupR4(const std::vector<Rectangle>& obstacles)
{   
    
    std::cout << "Please Enter the robots"<<std::endl;
    extern int robots;
    extern int robots_copy;
    std::cin >> robots;
    robots_copy =robots;
    int dimension = robots*2;


    // set up Rn space
    ompl::base::StateSpacePtr r(new ompl::base::RealVectorStateSpace(dimension));
    ompl::base::RealVectorBounds bounds(dimension);
    bounds.setLow(0); 
    bounds.setHigh(400); 
    r->as<ompl::base::RealVectorStateSpace>()->setBounds(bounds);

    // define problem
    ompl::geometric::SimpleSetup ss(r);
    ss.setStateValidityChecker(std::bind(isValidStatePoint, std::placeholders::_1, obstacles, bounds,robots));

    ompl::base::ScopedState<> start(r);
    
/*	int *sx =NULL;
	int *gx =NULL;

	std::cout<<robots<<" robots"<<std::endl;	
	sx = new int[dimension];
	gx = new int[dimension];	
	
	for(int i=0 ; i< robots; i++)     
	{
	int e =i*2; // even indicator, x
	int o =2*i+1; // odd indicator, y

label1:
	std::cout<<"Please enter your start states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


	std::cout<<"Enter x"<< i << "for start:";
	std::cin>>sx[e];
	std::cout<<"Enter y"<< i << "for start:";
	std::cin>>sx[o];


		if (isValidPoint(sx[e],sx[o],obstacles) == false)
		{
			std::cout<<"points collide with obstacles"<<std::endl;
		  	std::cout<< "enter again"<<std::endl;
		  	goto label1;
		}         

		    start[e]= sx[e];
		    start[o]= sx[o];
 	}
*/
    ompl::base::ScopedState<> goal(r);


/*	for(int n=0 ; n< robots; n++)     
		{
		    int e =n*2; // even indicator, x
		    int o =2*n+1; // odd indicator, y

	label2:
		std::cout<<"Please enter your goal states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


		std::cout<<"Enter x"<< n << "for goal:";
		std::cin>>gx[e];
		std::cout<<"Enter y"<< n << "for goal:";
		std::cin>>gx[o];


			if (isValidPoint(gx[e],gx[o],obstacles) == false)
			{
				std::cout<<"points collide with obstacles"<<std::endl;
			  	std::cout<< "enter again"<<std::endl;
			  	goto label2;
			}         

			    goal[e]= gx[e];
			    goal[o]= gx[o];
	 	} */


		    start[0]= 60;
		    start[1]= 300;
		    start[2]= 60;
		    start[3]= 250;
		    /*start[4]= 60;
		    start[5]= 200;
		    start[6]= 60;
		    start[7]= 150;
		    start[8]= 60;
		    start[9]= 100;
		    start[10]= 130;
		    start[11]= 200;
		    start[12]= 130;
		    start[13]= 250;
		    start[14]= 130;
		    start[15]= 75;
 
		   /* start[0] = 200;
		    start[1] = 70;
		    start[2] = 203;
		    start[3] = 75; */
 
		   // start[4]= 208;
		   // start[5]= 69;
			
		    //goal[0]= 94.8;
		    //goal[1]= 151.9;
		   // goal[2]= 288.7;
		    //goal[3]= 230.5;
		   // goal[4]= 303;
		   // goal[5]= 132;

		    goal[0]= 330;
		    goal[1]= 300;
		    goal[2]= 330;
		    goal[3]= 200;
		   /* goal[4]= 330;
		    goal[5]= 250;
		    goal[6]= 330;
		    goal[7]= 150; 
		    goal[8]= 330;
		    goal[9]= 100;
		    goal[10]= 280;
		    goal[11]= 200;
		    goal[12]= 280;
		    goal[13]= 250;
		    goal[14]= 280;
		    goal[15]= 75;
 
//////////////////////////////////////ENV 5//////////////////////////////////
		   /* start[0]= 222;
		    start[1]= 74;
		    start[2]= 227;
		    start[3]= 104;
		    start[4]= 230;
		    start[5]= 89.2;


	            goal[0]= 113.6;
		    goal[1]= 225;
		    goal[2]= 236.3;
		    goal[3]= 271;
		    goal[4]= 186.5;
		    goal[5]= 269.8;*/


/////////////////////////////////////////////////////////////////////////////

    ss.setStartAndGoalStates(start, goal);

    ompl::base::PlannerPtr planner(new ompl::geometric::RRT(ss.getSpaceInformation()));
    ss.setPlanner(planner);

    // run solver
    ompl::base::PlannerStatus solved = ss.solve(1.0);

    if (solved)
    {
        // ss.simplifySolution();

        // print the path to screen
        std::cout << "Found solution:" << std::endl;
        ompl::geometric::PathGeometric& path = ss.getSolutionPath();
        path.printAsMatrix(std::cout);

        // print path to file
        std::ofstream fout("path.txt");
       // fout << "R4 " << std::endl;
	fout << robots << std::endl;
        path.printAsMatrix(fout);


	for(int i=0 ; i< robots*2 ; i++)
	{

	fout<<goal[i]<<" ";
	}
	fout<<std::endl;

	fout.close();

        std::vector<Tree> tree; // initialization
	
       // Drawgrid(tree);

        // print obstacles to file
        std::ofstream eout("env.txt");
        for (Rectangle rect : obstacles)
        {
            eout << rect.x << " " << rect.y << " " << rect.width << " " << rect.height << " " << std::endl;
        }
        eout.close();
    }
    else
        std::cout << "No solution found" << std::endl;
}


void ReuseRRT(const std::vector<Rectangle>& obstacles)
{
    std::cout << "Please Enter the robots"<<std::endl;
    extern int robots;
    extern int robots_copy;
    std::cin >> robots;
    robots_copy =robots;
    int dimension = robots*2;


    // set up Rn space
    ompl::base::StateSpacePtr r(new ompl::base::RealVectorStateSpace(dimension));
    ompl::base::RealVectorBounds bounds(dimension);
    bounds.setLow(0); 
    bounds.setHigh(400); 
    r->as<ompl::base::RealVectorStateSpace>()->setBounds(bounds);

    // define problem
    ompl::geometric::SimpleSetup ss(r);
    ss.setStateValidityChecker(std::bind(isValidStatePoint, std::placeholders::_1, obstacles, bounds,robots));

    ompl::base::ScopedState<> start(r);
  	 
/*	int *sx =NULL;
	int *gx =NULL;

	std::cout<<robots<<" robots"<<std::endl;	
	sx = new int[dimension];
	gx = new int[dimension];	
	
	for(int i=0 ; i< robots; i++)     
	{
	int e =i*2; // even indicator, x
	int o =2*i+1; // odd indicator, y

label1:
	std::cout<<"Please enter your start states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


	std::cout<<"Enter x"<< i << "for start:";
	std::cin>>sx[e];
	std::cout<<"Enter y"<< i << "for start:";
	std::cin>>sx[o];


		if (isValidPoint(sx[e],sx[o],obstacles) == false)
		{
			std::cout<<"points collide with obstacles"<<std::endl;
		  	std::cout<< "enter again"<<std::endl;
		  	goto label1;
		}         

		    start[e]= sx[e];
		    start[o]= sx[o];
 	}
*/
    ompl::base::ScopedState<> goal(r);


/*	for(int n=0 ; n< robots; n++)     
		{
		    int e =n*2; // even indicator, x
		    int o =2*n+1; // odd indicator, y

	label2:
		std::cout<<"Please enter your goal states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


		std::cout<<"Enter x"<< n << "for goal:";
		std::cin>>gx[e];
		std::cout<<"Enter y"<< n << "for goal:";
		std::cin>>gx[o];


			if (isValidPoint(gx[e],gx[o],obstacles) == false)
			{
				std::cout<<"points collide with obstacles"<<std::endl;
			  	std::cout<< "enter again"<<std::endl;
			  	goto label2;
			}         

			    goal[e]= gx[e];
			    goal[o]= gx[o];
	 	} */

// Start for 8 robots 

		    /*start[0]= 60;
		    start[1]= 300;
		    start[2]= 60;
		    start[3]= 250;
		    start[4]= 60;
		    start[5]= 200;
		    start[6]= 60;
		    start[7]= 150;
		    start[8]= 60;
		    start[9]= 100;
		    start[10]= 130;
		    start[11]= 200;
		    start[12]= 130;
		    start[13]= 250;
		    start[14]= 130;
		    start[15]= 75;*/

// Start for 4 robots

		    start[0]= 60;
		    start[1]= 300;
		    start[2]= 60;
		    start[3]= 250;
		    start[4]= 60;
		    start[5]= 200;
		    start[6]= 60;
		    start[7]= 150;
 
		   /* start[0] = 200;
		    start[1] = 70;
		    start[2] = 203;
		    start[3] = 75; */
 
		   // start[4]= 208;
		   // start[5]= 69;
			
		    //goal[0]= 94.8;
		    //goal[1]= 151.9;
		   // goal[2]= 288.7;
		    //goal[3]= 230.5;
		   // goal[4]= 303;
		   // goal[5]= 132;

// Goal for 8 robots

		    /*goal[0]= 330;
		    goal[1]= 300;
		    goal[2]= 330;
		    goal[3]= 200;
		    goal[4]= 330;
		    goal[5]= 250;
		    goal[6]= 330;
		    goal[7]= 150; 
		    goal[8]= 330;
		    goal[9]= 100;
		    goal[10]= 280;
		    goal[11]= 200;
		    goal[12]= 100;
		    goal[13]= 250;
		    goal[14]= 300;
		    goal[15]= 75;*/

	    	    goal[0]= 330;
		    goal[1]= 100;
		    goal[2]= 280;
		    goal[3]= 200;
		    goal[4]= 100;
		    goal[5]= 250;
		    goal[6]= 300;
		    goal[7]= 75;




    ss.setStartAndGoalStates(start, goal);

    ompl::base::PlannerPtr planner(new ompl::geometric::RU(ss.getSpaceInformation()));
    ss.setPlanner(planner);

    // run solver
    ompl::base::PlannerStatus solved = ss.solve(5.0);

if (solved)
    {
        // ss.simplifySolution();

        // print the path to screen
        std::cout << "Found solution:" << std::endl;
        ompl::geometric::PathGeometric& path = ss.getSolutionPath();
        path.printAsMatrix(std::cout);

        // print path to file
        std::ofstream fout("path.txt");
	fout << robots << std::endl;
        path.printAsMatrix(fout);


	for(int i=0 ; i< robots*2 ; i++)
	{

	fout<<goal[i]<<" ";
	}
	fout<<std::endl;
	fout.close();

        std::vector<Tree> tree; // initialization
	
       // Drawgrid(tree);

        // print obstacles to file
        std::ofstream eout("env.txt");
        for (Rectangle rect : obstacles)
        {
            eout << rect.x << " " << rect.y << " " << rect.width << " " << rect.height << " " << std::endl;
        }
        eout.close();
    }
    else
        std::cout << "No solution found" << std::endl;
}

std::vector<Rectangle> obstacles;
std::vector<Rectangle> CallObstacle()	
	{
	 	return obstacles;
	}


int main(int, char **)
{
    
    int env;
    // select robot
    int robot;
    do
    {
        std::cout << "Plan for: "<< std::endl;
        std::cout << " (1) 2 point robot in 2D" << std::endl;
        std::cout << " (2) Reuse the old RRT Tree" << std::endl;
        std::cin >> robot;

    } while (robot < 1 || robot > 2);
    
    // select environment
   
    do
    {
        std::cout << "In environment 1 , 2 ,3 4,5: "<< std::endl;
        
        std::cin >> env;
    } while (env < 1 || env > 5);

    // create environment
    switch(env)
    {
    case 1:
        obstacles = defineEnv1();
        break;
    case 2:
        obstacles = defineEnv2();
        break;    
    case 3:
        obstacles = defineEnv3();
        break;    
    case 4:
        obstacles = defineEnv4();
        break;    
    case 5:
        obstacles = defineEnv5();
        break;
     
    }
    
    
  

    // plan path
    switch(robot)
    {
    case 1:
        planWithSimpleSetupR4(obstacles);
        break;
    case 2:
        ReuseRRT(obstacles);
        break;
    }
    
    return 0;
}
