#include <ompl/geometric/planners/PlannerIncludes.h>

namespace ompl
{
    namespace geometric
    {
        class RTP : public base::Planner
        {
        public:
            RTP(const base::SpaceInformationPtr &si);

            ~RTP() override;

            void getPlannerData(base::PlannerData &data) const override;

            base::PlannerStatus solve(const base::PlannerTerminationCondition &ptc) override;

            void clear() override;

        protected:
            void freeMemory();

            // vector containing parent states
            // of corresponding state in tree_states
            std::vector<int> tree_;

            // vector of configuration states in tree
            std::vector<base::State*> tree_states_;
            base::StateSamplerPtr sampler_;
        };
    }
}

