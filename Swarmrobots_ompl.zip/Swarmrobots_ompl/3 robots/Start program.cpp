int *sx =NULL;
	int dimension = robots*2;	
	sx = new int[dimension];	
	
	for(int i=0 ; i< dimension; i++)     
	{
	int e =i*2; // even indicator, x
	int o =2*i+1; // odd indicator, y

label1:
	std::cout<<"Please enter your goal states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


	std::cout<<"Enter x"<< i << "for start:";
	std::cin>>sx[e];
	std::cout<<"Enter y"<< i << "for start:";
	std::cin>>sx[o];


		if (isValidPoint(sx[e],sx[o],obstacles) == false)
		{
			std::cout<<"points collide with obstacles"<<std::endl;
		  	std::cout<< "enter again"<<std::endl;
		  	goto label1;
		}         

		    start[e]= sx[e];
		    start[o]= sx[o];

 	}
