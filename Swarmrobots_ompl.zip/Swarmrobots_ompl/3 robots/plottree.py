#!/usr/bin/env python
from mpl_toolkits.mplot3d import Axes3D, art3d
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import sys
from math import sin, cos

# Draw some obstacles
def plotObstacle(ax, x, y, width, height):
    ax.add_patch(patches.Polygon([(x, y), (x+width, y), (x+width, y+height), (x, y+height)], fill=True, color='0.20',zorder=3))

def plotPoint(ax, x, y, c='r'):
    ax.add_patch(patches.CirclePolygon((x, y), 3, color=c,zorder=4))

def plotPointg(ax, x, y, c='r'):
    ax.add_patch(patches.Wedge((x, y), 20, 0,360,width=0.5, color=c,zorder=5))


#def plotlines(ax,x,y,width,colour):
#	ax.add_line()

def plot2Robots(path, env,tree):
    fig = plt.figure()
    ax = fig.gca()
    plt.xlim(0, 450)
    plt.ylim(0, 450)
    plt.gca().set_aspect('equal', adjustable='box')

    plotPointg(ax, 320, 313,'k')
    plotPointg(ax, 320, 95,'k')
    # plot obstacles
    for obs in env:
        plotObstacle(ax, obs[0], obs[1], obs[2], obs[3])



    i=0
    while(i<len(tree)):
	X=[tree[i][0],tree[(i+1)][0]]
	Y=[tree[i][1],tree[(i+1)][1]]
	ax.plot(X, Y, 'c-',zorder=2)
	X=[tree[i][2],tree[(i+1)][2]]
	Y=[tree[i][3],tree[(i+1)][3]]
	ax.plot(X, Y, 'y-',zorder=2)
	#X=[(tree[i][2]+tree[i][0])/2,(tree[(i+1)][0]+tree[(i+1)][2])/2]
	#Y=[(tree[i][1]+tree[i][3])/2,(tree[(i+1)][3]+tree[(i+1)][1])/2]
	#ax.plot(X, Y, 'g')
	#plt.update()
	i=i+2
	

	# Plotting the path (reference point)
    X = [p[0] for p in path[:-1]] 
    Y = [p[1] for p in path[:-1]]
    ax.plot(X, Y, 'b-',3)
    X = [p[2] for p in path[:-1]]
    Y = [p[3] for p in path[:-1]]
    ax.plot(X, Y, 'r-',4)

    # plot start and end points    
    plotPoint(ax, path[0][0], path[0][1],'k')
    plotPoint(ax, path[-2][0], path[-2][1],'b')
    plotPoint(ax, path[0][2], path[0][3],'g')
    plotPoint(ax, path[-2][2], path[-2][3],'r')

    # plot circle at the goals
    plotPointg(ax, path[-1][0], path[-1][1],'b')
    plotPointg(ax, path[-1][2], path[-1][3],'r')


    #plotPointg(ax, 300, 80, 'g')
    #plotPointg(ax, 320, 95, 'g')



    plt.show()
    

# Read the system and the path from filename
def readPath(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]

    if len(lines) == 0:
        print "That file's empty!"
        sys.exit(1)
	
    data = [[float(x) for x in line.split(' ')] for line in lines[1:]]

    return data


# Read the tree from filename
def readTree(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]

    if len(lines) == 0:
        print "That file's empty!"
        sys.exit(1)
	
    data = [[float(x) for x in line.split(' ')] for line in lines[1:]]

    return data
    
# read obstacles from file
def readEnv(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]
    data = [[float(x) for x in line.split(' ')] for line in lines]
    return data

def readPD(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]
    data = [[float(x) for x in line.split(' ')] for line in lines]
    return data


if __name__ == '__main__':
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = 'path.txt'

    path = readPath(filename)
    env = readEnv('env.txt') 
    tree = readTree('file.txt')
    
    plot2Robots(path, env,tree)

    
    
	



