
#ifndef COLLISION_H_
#define COLLISION_H_

#include <vector>
#include <cmath>
#include <iostream>
#include <array>
#include "CollisionChecking.h"
const double pi =3.14159265358979323846;


struct MoveRobot
{
    // Movement of the robot in x and y direction-steps when keys are pressed
    double x1, y1,x2,y2;

};

struct Start_Goal
{
        //Start and Goal points (small circle with radius)
        double x, y;
        double radius;

};



struct Temp_Var
{
        //Temp to store variable
        double x, y;
        double radius;

};

struct Commands

{
    // Command from the file to move the robot
   double length;

   double angle;
};


struct Tree

{
  double tx1;
  double ty1;
  double tx2;
  double ty2;
  
};

//Read command file to give commands
bool readFile(int argc, char** argv, std::vector<Commands>& command);
bool readRRTFile(int argc, char** argv);
void Nextpoint(double x1,double y1,double distance , double angle,double p[]);
//double *Nextpoint(double x1,double y1,double distance , double angle);
double calcDistance(double a[], double b[]);

double *ApplyMove(double ax, double ay, double bx, double by , double movedist,double angle);

//calculate Euclidian distances
double Cal_Distance(double x1, double y1 ,double x2,double y2);

// calculate whether nodes of the tree is inside the cube
bool isPointinGrid(double x1, double y1,double x2, double y2,std::array<std::array<double, 4>, 812000 > array,int delta, int gridNo);
//bool isPointinGrid(double x1, double y1,double x2, double y2,std::array<std::array<std::array<double, 4>, 16>,256> array,int delta, int gridNo);
//bool isPointinGrid(double x1, double y1,double x2, double y2,double array[][16][4],int delta, int gridNo);
 
//bool isPointinGrid(double x1, double y1,double x2,double y2, std::array<std::array<double,4>,256> array,int delta, int gridNo);
void Drawgrid();

// fetch tree
  std::vector<Tree> calltree();
// fetch tree
  std::vector<Tree> calltree1();
// fetch env
   std::vector<Rectangle> callEnv();
   std::vector<Rectangle> CallObstacle();	

#endif
