#!/usr/bin/env python
from mpl_toolkits.mplot3d import Axes3D, art3d
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.cm as cm
import sys
from math import sin, cos



#colors = cm.rainbow(np.linspace(0, 1, robots))

colors =['r','b','g','y','c','m','k','brown','grey']
# Draw some obstacles
def plotObstacle(ax, x, y, width, height):
    ax.add_patch(patches.Polygon([(x, y), (x+width, y), (x+width, y+height), (x, y+height)], fill=True, color='0.20',zorder=3))
side =3
def plotSquare(ax, x, y,c='b'):
    ax.add_patch(patches.Polygon([(x-side,y-side),(x+side,y-side),(x+side,y+side),(x-side,y+side)],fill=True , color =c,zorder=5))

def plotPoint(ax, x, y,c='b'):
    ax.add_patch(patches.CirclePolygon((x, y), 4,color=c,zorder=4))

def plotPointg(ax, x, y, c='r'):
    ax.add_patch(patches.Wedge((x, y), 20, 0,360,width=2, color=c,linestyle='dashed',hatch='+',zorder=5))

def plot2Robots(path, env):

    f = open('path.txt')
    data = f.read()
    robots = data.split('\n', 1)[0]
    robots = int(robots)
    fig = plt.figure()
    ax = fig.gca()
    plt.gca().set_aspect('equal', adjustable='box')

    # plot obstacles
    for obs in env:
        plotObstacle(ax, obs[0], obs[1], obs[2], obs[3])


    # plot start and end points 

 
    for i, c in zip(range(robots),colors):
        ex =i*2
        oy =2*i+1	  
        plotPoint(ax, path[0][ex], path[0][oy],c)
        plotSquare(ax, path[-2][ex], path[-2][oy],c)


    #plotPoint(ax, 300, 80, 'g')
    #plotPoint(ax, 320, 95, 'g')

    for j, c in zip(range(robots),colors):
        ex =j*2;
        oy =2*j+1;	  
        plotPointg(ax, path[-1][ex], path[-1][oy],c)


    # Plotting the path (reference point)
    for k, c in zip(range(robots),colors):
        ex =k*2;
        oy =2*k+1;
        X = [p[ex] for p in path[:-1]] 
        Y = [p[oy] for p in path[:-1]]
        ax.plot(X, Y, c,zorder=2)

    plt.xlim(0, 450)
    plt.ylim(0, 450)
    plt.show()

def plot4Robots(path, env):
    fig = plt.figure()
    ax = fig.gca()

    # plot obstacles
    for obs in env:
        plotObstacle(ax, obs[0], obs[1], obs[2], obs[3])

    # plot start and end points    
    plotPoint(ax, path[0][0], path[0][1],'b')
    plotPoint(ax, path[-2][0], path[-2][1],'b')
    plotPoint(ax, path[0][2], path[0][3],'r')
    plotPoint(ax, path[-2][2], path[-2][3],'r')
    plotPoint(ax, path[0][4], path[0][5],'g')
    plotPoint(ax, path[-2][4], path[-2][5],'g')
    plotPoint(ax, path[0][6], path[0][7],'k')
    plotPoint(ax, path[-2][6], path[-2][7],'k')


    plotPointg(ax, path[-1][0], path[-1][1],'b')#b
    plotPointg(ax, path[-1][2], path[-1][3],'r')#r
    plotPointg(ax, path[-1][4], path[-1][5],'g')#b
    plotPointg(ax, path[-1][6], path[-1][7],'k')#r

    # Plotting the path (reference point)
    X = [p[0] for p in path[:-1]] 
    Y = [p[1] for p in path[:-1]]
    ax.plot(X, Y, 'b-')
    X = [p[2] for p in path[:-1]] 
    Y = [p[3] for p in path[:-1]]
    ax.plot(X, Y, 'r-')
    X = [p[4] for p in path[:-1]] 
    Y = [p[5] for p in path[:-1]]
    ax.plot(X, Y, 'g-')
    X = [p[6] for p in path[:-1]] 
    Y = [p[7] for p in path[:-1]]
    ax.plot(X, Y, 'k-')

   # for p in path:
    #    plotPoint(ax, p[0], p[1], 0.2, 'b')
    #    plotPoint(ax, p[2], p[3], 0.2, 'r')
    #    plotPoint(ax, p[4], p[5], 0.4, 'g')
    #    plotPoint(ax, p[6], p[7], 0.4, 'k')

    plt.xlim(0, 450)
    plt.ylim(0, 450)
    plt.show()

def plot8Robots(path, env):
    fig = plt.figure()
    ax = fig.gca()

    # plot obstacles
    for obs in env:
        plotObstacle(ax, obs[0], obs[1], obs[2], obs[3])

    # Plotting the path (reference point)
    X = [p[0] for p in path] 
    Y = [p[1] for p in path]
    ax.plot(X, Y, 'b-')
    X = [p[2] for p in path]
    Y = [p[3] for p in path]
    ax.plot(X, Y, 'r-')
    X = [p[4] for p in path]
    Y = [p[5] for p in path]
    ax.plot(X, Y, 'g-')
    X = [p[6] for p in path]
    Y = [p[7] for p in path]
    ax.plot(X, Y, 'k-')
    X = [p[8] for p in path]
    Y = [p[9] for p in path]
    ax.plot(X, Y, 'b--')
    X = [p[10] for p in path]
    Y = [p[11] for p in path]
    ax.plot(X, Y, 'r--')
    X = [p[12] for p in path]
    Y = [p[13] for p in path]
    ax.plot(X, Y, 'g--')
    X = [p[14] for p in path]
    Y = [p[15] for p in path]
    ax.plot(X, Y, 'k--')

    plotPoint(ax, path[0][0], path[0][1], 0.1)
    plotPoint(ax, path[0][2], path[0][3], 0.1)
    plotPoint(ax, path[0][4], path[0][5], 0.1)
    plotPoint(ax, path[0][6], path[0][7], 0.1)
    plotPoint(ax, path[0][8], path[0][9], 0.1)
    plotPoint(ax, path[0][10], path[0][11], 0.1)
    plotPoint(ax, path[0][12], path[0][13], 0.1)
    plotPoint(ax, path[0][14], path[0][15], 0.1)

    plt.xlim(0, 450)
    plt.ylim(0, 450)
    plt.show()

# for debugging
def plotPRM(pd):
    fig = plt.figure()
    ax = fig.gca()

    # plot obstacles
    for obs in env:
        plotObstacle(ax, obs[0], obs[1], obs[2], obs[3])

    for p in pd:
        plotPoint(ax, p[0], p[1])

    plt.xlim(-5, 5)
    plt.ylim(-5, 5)
    plt.show()


# Read the system and the path from filename
def readPath(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]

    if len(lines) == 0:
        print "That file's empty!"
        sys.exit(1)
	
    data = [[float(x) for x in line.split(' ')] for line in lines[1:]]

    return data
    
# read obstacles from file
def readEnv(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]
    data = [[float(x) for x in line.split(' ')] for line in lines]
    return data

def readPD(filename):
    lines = [line.rstrip() for line in open(filename) if len(line.rstrip()) > 0]
    data = [[float(x) for x in line.split(' ')] for line in lines]
    return data


if __name__ == '__main__':
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = 'path.txt'

    path = readPath(filename)
    env = readEnv('env.txt')
    plot2Robots(path, env)
    
    
	



