THis program has solved 
1)Obstales call
2)Python plot read number if robots
