#include "RU.h"
#include "ompl/base/goals/GoalSampleableRegion.h"
#include "ompl/tools/config/SelfConfig.h"
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/PlannerData.h>
#include "CollisionChecking.h"
#include <iostream>
#include <fstream>
#include <limits>
#include "Collision.h"

 bool approx = false;

 
ompl::geometric::RU::RU(const base::SpaceInformationPtr &si) : base::Planner(si, "RU")
{
    specs_.approximateSolutions = true;
    
}

ompl::geometric::RU::~RU()
{
    freeMemory();
}

void ompl::geometric::RU::clear()
{
    Planner::clear();
    freeMemory();
}


 //#############################################################################################
 // Reading in all configs
    std::vector<Tree> Parent;
    std::vector<Tree> Child;    


ompl::base::PlannerStatus ompl::geometric::RU::solve(const base::PlannerTerminationCondition &ptc)
{

    checkValidity();
    
    // get start and goal states
    base::State* start = pdef_->getStartState(0);
    base::Goal* goal = pdef_->getGoal().get();

    
    //base::State* qa = si_->allocState();
    //si_->copyState(qa, start);
    //tree_.push_back(-1);
    //tree_states_.push_back(qa); 
   // if (tree_states_.size() == 0)
    //{
     //  OMPL_ERROR("%s: There are no valid initial states!", getName().c_str());
       // return base::PlannerStatus::INVALID_START;
    //}

    OMPL_INFORM("%s: Starting planning with %u states already in datastructure", getName().c_str(), tree_states_.size());


    
    double approxdif = std::numeric_limits<double>::infinity();
    
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* Open the preobtained RRT and use it to find the solution*/
    std::ifstream fin;
    fin.open("file.txt");
    
    if (!fin)
    {
        std::cout << "Fatal: Failed to open " << std::endl;
        
    }
    int count =0;
    
    while(!fin.eof())
    {   



	// Ignore text in the beginning
	fin.ignore( 20, '\n' );


        // Read in the commands
        base::State *childstate = si_->allocState();
        base::State *Parentstate = si_->allocState();

        Tree data1;
	fin >> Parentstate->as<base::RealVectorStateSpace::StateType>()->values[0];        
	fin >> Parentstate->as<base::RealVectorStateSpace::StateType>()->values[1];
	fin >> Parentstate->as<base::RealVectorStateSpace::StateType>()->values[2];
	fin >> Parentstate->as<base::RealVectorStateSpace::StateType>()->values[3];
        parent_states_.push_back(Parentstate);


        Tree data2;
	fin >> childstate->as<base::RealVectorStateSpace::StateType>()->values[0];        
	fin >> childstate->as<base::RealVectorStateSpace::StateType>()->values[1];
	fin >> childstate->as<base::RealVectorStateSpace::StateType>()->values[2];
	fin >> childstate->as<base::RealVectorStateSpace::StateType>()->values[3];
        tree_states_.push_back(childstate);        
	
	tree_.push_back(count);
	count =count +1;
       }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Parent and child vectors are created ,Now use it to plot the tree
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
        int end_parent;
        int Parent_idx;
        base::State* end; 
	      
	
        // set last point as temp goal
        int closest_idx = tree_.size() - 1;
        double* distance = new double;
        goal->isSatisfied(tree_states_[closest_idx], distance);
        double closest_distance = *distance;

        // find state closest to goal
        for (int idx = 0; idx < tree_.size(); idx++)

        {   
            goal->isSatisfied(tree_states_[idx], distance);            
            if (*distance < closest_distance)

            {    // std::cout<<"distance"<<*distance<<std::endl;           
                closest_distance = *distance;
                closest_idx = idx;
            }      
        }
        end = tree_states_[closest_idx];
        end_parent = closest_idx;  
        base::State* goal_states_ = si_->allocState();
        si_->copyState(goal_states_, end);
    

        delete distance;

	std::cout<<"end 1 " <<end->as<base::RealVectorStateSpace::StateType>()->values[0]<<" "<<
	end->as<base::RealVectorStateSpace::StateType>()->values[1]<<" "<<
	end->as<base::RealVectorStateSpace::StateType>()->values[2]<<" "<<
	end->as<base::RealVectorStateSpace::StateType>()->values[3]<< std::endl; 

	if (goal->isSatisfied(end))
            {
                bool approx = false;
            }
         else 
	    {
		bool approx = true;
	     }
      
	auto path(std::make_shared<PathGeometric>(si_));
         
    // add goal state
    	path->append(end);
    	Parent_idx = end_parent;
	path->append(parent_states_[Parent_idx]);

      while(si_->equalStates(parent_states_[Parent_idx], start)==false)
	{   std::cout<< "distance "<< si_->distance(parent_states_[Parent_idx], start)<<std::endl;

		for (int idx = 0; idx < tree_.size()-1; idx++)
		{
			   if (si_->equalStates(parent_states_[Parent_idx], tree_states_[idx])==true)
		
				{
				Parent_idx = idx;
				//std::cout<<"idx"<<idx<<std::endl;
				break;
				}

		}
		
                   
		path->append(parent_states_[Parent_idx]);
	}
	
	path->reverse();
    
    // add path to solution
    pdef_->addSolutionPath(path);

    // always returns a solution
    // approx flag if exact goal not reached
    return base::PlannerStatus(true, approx); 
}

std::vector<Tree> calltree1()
{
 return Parent;
 
}
void ompl::geometric::RU::freeMemory()
{
    // free all other states in tree
    for (int i = 0; i < tree_states_.size(); i++)
    {
        si_->freeState(tree_states_[i]);
	si_->freeState(parent_states_[i]);	
    }

    tree_states_.clear();
    parent_states_.clear();
}

void ompl::geometric::RU::getPlannerData(base::PlannerData &data) const
{
    Planner::getPlannerData(data);

    // add goal vertex if it exists
    base::Goal* goal = pdef_->getGoal().get();
    if (goal->isSatisfied(tree_states_.back()))
    {
        data.addGoalVertex(base::PlannerDataVertex(tree_states_.back()));
    }
    base::State* start = pdef_->getStartState(0);
    for (int i = 0; i < tree_.size(); i++)	
    {	
         //add start vertex
	// add edge from parent state to state
        // goal will not be duplicated since it is already added
        if ((si_->equalStates(parent_states_[i], start)==true))
        {  
            data.addStartVertex(base::PlannerDataVertex(parent_states_[i]));
        }        
        else
        {
            data.addEdge(base::PlannerDataVertex(parent_states_[i]), base::PlannerDataVertex(tree_states_[i]));
        }
    }
}

