#include <cstdlib>
#include <vector>
#include <cmath>
#include <iostream>
#include <fstream>
#include <cstring>
#include "Collision.h"
#include <iterator>
#include <algorithm>
#include <set>
#include <list>
#include <array>
#include <algorithm>

#include <cctype>


 double a=0;
 double b=0;
 double c=0;
 double d=0;

 double Xaxis =350;
 double Yaxis =350;
 double Zaxis =350;
 double Haxis =350;
 int dimension = 4;
 int cellsize ,delta= 50;

 double nx(Xaxis/delta),ny(Xaxis/delta),nz(Xaxis/delta),nh(Xaxis/delta);

 int inx =50; // 50 is the width of the border around the enviornment
 int iny =50;
 int inz =50;
 int inh =50;
 int shift = inx/delta;
 double x(50),y(50),z(50),h(50);

 double Total_Cell= std::pow((nx-shift),dimension);
 //double Grid[10000][16][4];

 double Total_coord = std::pow(2,dimension);

 int m=0;

 //std::array<std::array<std::array<double, 4>, 16>,256> Grid;
  std::array<std::array<double,4>,4096> Grid;

 void Drawgrid(const std::vector<Tree> tree) 

 { 

for (int p=0; p < nx-shift; ++p){      // 
    h=inh + p*delta;

    for (int i=0; i < ny-shift; ++i){
        z=inz + i*delta;

        for (int j=0; j < nz-shift; ++j){
            y = iny + j*delta;

            for (int k=0; k < nh-shift; ++k){
                x = inx+ k*delta;

                  Grid[m]= {x,       y,      z,       h};
                 /* Grid[m][1]= {x+delta, y,      z,       h};
                  Grid[m][2]= {x,       y+delta,z,       h};
                  Grid[m][3]= {x+delta, y+delta,z,       h};
                  Grid[m][4]= {x,       y,      z+delta, h};
                  Grid[m][5]= {x+delta, y,      z+delta, h};
                  Grid[m][6]= {x,       y+delta,z+delta, h};
                  Grid[m][7]= {x+delta, y+delta,z+delta, h};
                  Grid[m][8]= {x,       y,      z,       h+delta};
                  Grid[m][9]= {x+delta, y,      z,       h+delta};
                  Grid[m][10]={x,      y+delta,z,       h+delta};
                  Grid[m][11]={x+delta,y+delta,z,       h+delta};
                  Grid[m][12]={x,      y,      z+delta, h+delta};
                  Grid[m][13]={x+delta,y,      z+delta, h+delta};
                  Grid[m][14]={x,      y+delta,z+delta, h+delta};
                  Grid[m][15]={x+delta,y+delta,z+delta, h+delta};*/

                m++;
            }
        }
    }
}

std::vector<long int> cover;
//double r1x(5) ,r1y(5),r2x(5),r2y(5) ;
//double Robot1x(70),Robot1y(70),Robot2x(70),Robot2y(70);
std::vector<Tree> ntree;
ntree = calltree();
		/*Tree node1;
		node1.tx1 = r1x;
		node1.ty1 = r1y;
		node1.tx2 = r2x;
		node1.ty2 = r2y;
		ntree.push_back(node1);

		Tree node2;
		node2.tx1 = Robot1x;
		node2.ty1 = Robot1y;
		node2.tx2 = Robot2x;
		node2.ty2 = Robot2y;
		ntree.push_back(node2);*/

    std::vector<Tree>::const_iterator tr;
    for (tr = ntree.begin(); tr < ntree.end(); tr++)
	{
	    a=tr->tx1;
	    b=tr->ty1;
	    c=tr->tx2;
	    d=tr->ty2;
	//std::cout<< a <<b<<c<<d<<std::endl;

           for (int i=0;i<Total_Cell;++i){
           if (isPointinGrid( a, b, c, d, Grid,delta, i)==true)
                {cover.push_back(i);}
            }
 	}
            //std::sort(cover.begin(), cover.end());
            //std::set<long int> uvec(cover.begin(), cover.end());
            //std::list<long int> output;

            //std::set_difference(cover.begin(), cover.end(),
                            //uvec.begin(), uvec.end(),
                            //back_inserter(output));

            //long int DuplicateGrids= output.size();

 	    std::sort(cover.begin(), cover.end());      //eg 1 1 2 2 3 3 3 4 4 5 5 6 7 
    	    auto last = std::unique(cover.begin(), cover.end());	// vector now holds {1 2 3 4 5 6 7 x x x x x x}, where 'x' is indeterminate
    	    cover.erase(last, cover.end());
            
            //int count = (cover.size() - DuplicateGrids);
	    std::cout<<"Total Grids" << Total_Cell<< std::endl;  
            std::cout<<"Counts of filled grids" << cover.size()<< std::endl;
            std::cout<<"Percentage coverage ="<< (cover.size()/Total_Cell * 100)<<std::endl;


}

// Print the Grid
     

   /* for (int i=0; i <Total_Cell; ++i)
    {
        //for (int j=0; j < 16; ++j)
        //{
            std::cout<< "  "<<std::endl;

            for (int k=0; k < 4; ++k)
            {
              std::cout<<Grid[i][k]<<"     ";

            }
        //}
    }
*/
