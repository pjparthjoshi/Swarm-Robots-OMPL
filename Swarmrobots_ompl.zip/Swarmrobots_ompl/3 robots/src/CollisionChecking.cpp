/////////////////////////////////////////
// COMP/ELEC/MECH 450/550
// Project 2
// Authors: Parth Joshi
// Date: 9/15/2017
//////////////////////////////////////

#include "CollisionChecking.h"

// Intersect the point (x,y) with the set of rectangles. If the point lies
// outside of all obstacles, return true.
bool isValidPoint(double x, double y,const std::vector<Rectangle>& obstacles)
{
    std::vector<Rectangle>::const_iterator obs;
    for (obs = obstacles.begin(); obs < obstacles.end(); obs++)
	{
        if (obs->x <= x && x <= obs->x + obs->width && obs->y <= y && y <= obs->y + obs->height)  
        {
                return false;
       
	}
 
	//if (obs->x <= x1 && x1 <= obs->x + obs->width && obs->y <= y1 && y1 <= obs->y + obs->height)

	//{

	//	return false;
	//}

 }
    return true;
}

// Intersect a circle with center (x,y) and given radius with the set of
// rectangles. If the circle lies outside of all obstacles, return true.
bool isValidCircle(double x, double y, double radius, const std::vector<Rectangle>& obstacles)
{
    std::vector<Rectangle>::const_iterator obs;
    for (obs = obstacles.begin(); obs < obstacles.end(); obs++)
    {
        if ((obs->x-radius <= x && x <= obs->x+obs->width+radius && obs->y <= y && y <= obs->y+obs->height) ||
            (obs->x <= x && x <= obs->x+obs->width && obs->y-radius <= y && y <= obs->y+obs->height+radius) ||
            ((x-obs->x)*(x-obs->x)+(y-obs->y)*(y-obs->y) <= radius*radius) ||
            ((x-obs->x-obs->width)*(x-obs->x-obs->width)+(y-obs->y)*(y-obs->y) <= radius*radius) ||
            ((x-obs->x)*(x-obs->x)+(y-obs->y-obs->height)*(y-obs->y-obs->height) <= radius*radius) ||
            ((x-obs->x-obs->width)*(x-obs->x-obs->width)+(y-obs->y-obs->height)*(y-obs->y-obs->height) <= radius*radius))
        {
            return false;
        }
    }
    return true;
}

bool intersectSegments(double A_x, double A_y, double B_x, double B_y, double C_x, double C_y, double D_x, double D_y)
{
    double m_AB, b_AB, m_CD, b_CD, int_x, int_y;
    // parallel vertical lines
    if (A_x == B_x && C_x == D_x)
    {
        return false;
    } 
    // one vertical line
    else if (A_x == B_x)
    {
        m_CD = (D_y - C_y) / (D_x - C_x);
        b_CD = C_y - m_CD * C_x;
        int_y = m_CD * A_x + b_CD;
        if (A_x >= std::min(C_x, D_x) && A_x <= std::max(C_x, D_x) &&
            int_y >= std::min(C_y, D_y) && int_y <= std::max(C_y, D_y) &&
            int_y >= std::min(A_y, B_y) && int_y <= std::max(A_y, B_y))
        {
            return true;
        }
        return false;
    }
    else if (C_x == D_x)
    {
        m_AB = (B_y - A_y) / (B_x - A_x);
        b_AB = A_y - m_AB * A_x;
        int_y = m_AB * C_x + b_AB;
        if (C_x >= std::min(A_x, B_x) && C_x <= std::max(A_x, B_x) &&
            int_y >= std::min(A_y, B_y) && int_y <= std::max(A_y, B_y) &&
            int_y >= std::min(C_y, D_y) && int_y <= std::max(C_y, D_y))
        {
            return true;
        }
        return false;
    }
    // compute line equations for AB and CD given endpoints
    m_AB = (B_y - A_y) / (B_x - A_x);
    b_AB = A_y - m_AB * A_x;
    m_CD = (D_y - C_y) / (D_x - C_x);
    b_CD = C_y - m_CD * C_x;
    
    // find intersection point (cosider lines collide eact other mx+c =mx+c)
    int_x = (b_CD - b_AB) / (m_AB - m_CD);
    int_y = m_AB * int_x + b_AB;

    // check intersection point is on line segments
    if (int_x >= std::min(A_x, B_x) && int_x <= std::max(A_x, B_x) &&
        int_x >= std::min(C_x, D_x) && int_x <= std::max(C_x, D_x) &&
        int_y >= std::min(A_y, B_y) && int_y <= std::max(A_y, B_y) &&
        int_y >= std::min(C_y, D_y) && int_y <= std::max(C_y, D_y))
    {
        return true;
    }
    return false;
}

// Intersect a square with center at (x,y), orientation theta, and the given
// side length with the set of rectangles. If the square lies outside of all
// obstacles, return true.
bool isValidSquare(double x, double y, double theta, double sideLength, const std::vector<Rectangle>& obstacles)
{
    // define rotated points
    // rotated bottom left corner
    double rot_bl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_bl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    // rotated bottom right corner
    double rot_br_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_br_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    // rotated top left corner
    double rot_tl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;
    // rotated top right corner
    double rot_tr_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tr_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;

    std::vector<Rectangle>::const_iterator obs;
    for (obs = obstacles.begin(); obs < obstacles.end(); obs++)
    {
        // define obstacle corners
        // bottom left corner
        double obs_bl_x = obs->x;
        double obs_bl_y = obs->y;
        // bottom right corner
        double obs_br_x = obs->x + obs->width;
        double obs_br_y = obs->y;
        // top left corner
        double obs_tl_x = obs->x;
        double obs_tl_y = obs->y + obs->height;
        // top right corner
        double obs_tr_x = obs->x + obs->width;
        double obs_tr_y = obs->y + obs->height;
        
        // check if square in obstacle
        if (x >= obs->x && x <= obs->x + obs->width && y >= obs->y && y <= obs->y + obs->height)
        {
            return false;
        }

        // check intersections between all line segments
        if (
            // obs_bl -> obs_br
            intersectSegments(obs_bl_x, obs_bl_y, obs_br_x, obs_br_y, rot_bl_x, rot_bl_y, rot_br_x, rot_br_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_br_x, obs_br_y, rot_bl_x, rot_bl_y, rot_tl_x, rot_tl_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_br_x, obs_br_y, rot_tl_x, rot_tl_y, rot_tr_x, rot_tr_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_br_x, obs_br_y, rot_tr_x, rot_tr_y, rot_br_x, rot_br_y) ||
            // obs_bl -> obs_tl
            intersectSegments(obs_bl_x, obs_bl_y, obs_tl_x, obs_tl_y, rot_bl_x, rot_bl_y, rot_br_x, rot_br_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_tl_x, obs_tl_y, rot_bl_x, rot_bl_y, rot_tl_x, rot_tl_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_tl_x, obs_tl_y, rot_tl_x, rot_tl_y, rot_tr_x, rot_tr_y) ||
            intersectSegments(obs_bl_x, obs_bl_y, obs_tl_x, obs_tl_y, rot_tr_x, rot_tr_y, rot_br_x, rot_br_y) ||
            // obs_tl -> obs_tr
            intersectSegments(obs_tl_x, obs_tl_y, obs_tr_x, obs_tr_y, rot_bl_x, rot_bl_y, rot_br_x, rot_br_y) ||
            intersectSegments(obs_tl_x, obs_tl_y, obs_tr_x, obs_tr_y, rot_bl_x, rot_bl_y, rot_tl_x, rot_tl_y) ||
            intersectSegments(obs_tl_x, obs_tl_y, obs_tr_x, obs_tr_y, rot_tl_x, rot_tl_y, rot_tr_x, rot_tr_y) ||
            intersectSegments(obs_tl_x, obs_tl_y, obs_tr_x, obs_tr_y, rot_tr_x, rot_tr_y, rot_br_x, rot_br_y) ||
            // obs_tr -> obs_br
            intersectSegments(obs_tr_x, obs_tr_y, obs_br_x, obs_br_y, rot_bl_x, rot_bl_y, rot_br_x, rot_br_y) ||
            intersectSegments(obs_tr_x, obs_tr_y, obs_br_x, obs_br_y, rot_bl_x, rot_bl_y, rot_tl_x, rot_tl_y) ||
            intersectSegments(obs_tr_x, obs_tr_y, obs_br_x, obs_br_y, rot_tl_x, rot_tl_y, rot_tr_x, rot_tr_y) ||
            intersectSegments(obs_tr_x, obs_tr_y, obs_br_x, obs_br_y, rot_tr_x, rot_tr_y, rot_br_x, rot_br_y))
        {
            return false;
        }
    }    
    return true;
}





bool isValidPath(double x1, double y1, double x2, double y2, const std::vector<Rectangle>& obstacles)
{
    // define rotated points


    std::vector<Rectangle>::const_iterator obs;
    for (obs = obstacles.begin(); obs < obstacles.end(); obs++)
    {
        // define obstacle corners
        // bottom left corner
        double obs_bl_x = obs->x;
        double obs_bl_y = obs->y;
        // bottom right corner
        double obs_br_x = obs->x + obs->width;
        double obs_br_y = obs->y;
        // top left corner
        double obs_tl_x = obs->x;
        double obs_tl_y = obs->y + obs->height;
        // top right corner
        double obs_tr_x = obs->x + obs->width;
        double obs_tr_y = obs->y + obs->height;
        
        // check if square in obstacle
   
        // check intersections between all line segments
        if (
            // obs_bl -> obs_br
            intersectSegments(obs_bl_x, obs_bl_y, obs_br_x, obs_br_y, x1, y1, x2, y2) ||

            // obs_bl -> obs_tl
            intersectSegments(obs_bl_x, obs_bl_y, obs_tl_x, obs_tl_y, x1, y1, x2, y2) ||

            // obs_tl -> obs_tr
            intersectSegments(obs_tl_x, obs_tl_y, obs_tr_x, obs_tr_y, x1, y1, x2, y2) ||

            // obs_tr -> obs_br
            intersectSegments(obs_tr_x, obs_tr_y, obs_br_x, obs_br_y, x1, y1, x2, y2))

        {
            return false;
        }
    }    
    return true;
}










// Add any custom debug / development code here. This code will be executed
// instead of the statistics checker (Project2.cpp). Any code submitted here
// MUST compile, but will not be graded.
void debugMode(const std::vector<Robot>& /*robots*/, const std::vector<Rectangle>& /*obstacles*/, const std::vector<bool>& /*valid*/)
{
}
