int *x =NULL;
	std::cout << "Please Enter the robots"<<std::endl;
	int robots;
	std::cin >> robots;
	
	x = new int[robots];	
	
     for(int i=0 ; i< (robots*2);i++)

     { 
	
	*(x + i)= r2state->values[i];
	
      }   

    // check bounds

     for(int i=0 ; i< (robots*2); i++)
      {
	int e =i*2; // even indicator, x
	int o =2*i+1; // odd indicator, y
  
  if (x[e] > bounds.high[0] || x[e] < bounds.low[0] || x[o] > bounds.high[1] || x[o] < bounds.low[1])
	{		
        return false;
	}  

      return true; //isValidPoint(x, y, x1,y1, obstacles);  	
     }

