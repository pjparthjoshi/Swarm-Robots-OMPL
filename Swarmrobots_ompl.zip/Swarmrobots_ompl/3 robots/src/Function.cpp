#include "Collision.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include "CollisionChecking.h"


double Cal_Distance(double x1, double y1 ,double x2,double y2)
{
        return(sqrt ( ((x2 - x1)*(x2 - x1)) + (y2 - y1)*(y2 - y1)));

}

bool readFile(int argc, char** argv, std::vector<Commands>& command)
{
    if (argc < 2)
    {
        std::cout << "Number of arguments passed are less" << std::endl;

        return false;
    }


    const char* filename = argv[1];

    // Opening filename
    std::ifstream fin;
    fin.open(filename);
    if (!fin)
    {
        std::cout << "Fatal: Failed to open " << filename << std::endl;
        return false;
    }
    // Reading in all configs
    while(true)
    {
        // Read in the commands
        Commands data;
        fin >> data.length;
        if (fin.eof()) // end of file
        std::cout<<data.length<<std::endl;
            break;


        fin >> data.angle ;
        if (fin.eof()) // end of file
        std::cout<<data.angle<<std::endl;
            break;


        command.push_back(data);
    }

    return true;
}




bool readRRTFile(int argc, char** argv)//std::vector<Tree>& command
{
    if (argc < 2)
    {
        std::cout << "Number of arguments passed are less" << std::endl;

        return false;
    }


    const char* filename = argv[1];

    // Opening filename
    std::ifstream fin;
    fin.open(filename);
    if (!fin)
    {
        std::cout << "Fatal: Failed to open " << filename << std::endl;
        return false;
    }

    // Reading in all configs
   // std::vector<Tree> inst;
    double a(0),b(0),c(0),d(0);
    while(!fin.eof())
    {
        // Read in the commands
       //Tree data;
	fin >> a; //data.tx1;        
	fin >> b; //data.ty1;
	fin >> c;//data.tx1;
	fin >> d;//data.tx2;
	std::cout<<"a "<<a <<"b "<<b<<"c "<<c<<"d "<< d<<std::endl;
 	//std::cout<<"check"<<std::endl;
        //inst.push_back(data);
    } 


    return true;
}


double *ApplyMove( double ax, double ay, double bx, double by , double movedist,double angle)

{
  //double r1* = Nextpoint(ax,ay, movedist,angle);
  //double r2* = Nextpoint(bx,by,movedist,angle);
  //double all[4] = {*r1,*(r1+1),*r2,*(r2+1)}	   

	
  // return (all);

}


double calcDistance(double a[] , double b[]) {
	double total = 0, diff;
	for (int n = 0; n < 4; n++) {
	diff = b[n] - a[n];
	total += diff * diff;
	}
	//std::cout<<"Sizeof expt: "<<(sizeof(a)/sizeof(a[0]));
	return (sqrt(total));
	}



void Nextpoint(double a,double b, double distance , double angle,double p[])

{  //  std::cout<<a<< "  --Passed--  "<<b<<std::endl;

     double c=0;
     double d=0;
     c = a + distance * cos(( angle * pi ) / 180);
     d = b + distance * sin(( angle * pi ) / 180);


     //radians = ( angle * pi ) / 180 ;
     //double p[2];
     p[0]=c;
     p[1]=d;

   //  std::cout<<distance<<"  --distanceangle--  "<<angle<< std::endl;
   //  std::cout<<c<<"  --obtained--  "<<d<< std::endl;
     //return (p);
}




//bool isPointinGrid(double x1, double y1,double x2, double y2,double array[][16][4],int delta, int gridNo)

//bool isPointinGrid(double x1, double y1,double x2,double y2, std::array<std::array<std::array<double, 4>, 16>,256> array,int delta, int gridNo)
bool isPointinGrid(double x1, double y1,double x2,double y2, std::array<std::array<double,4>,4096> array,int delta, int gridNo)
{

	    if ((x1 < (array[gridNo][0] + delta) && array[gridNo][0] <= x1) && (y1 < (array[gridNo][1] + delta) && array[gridNo][1] <= y1) &&
             (x2 < (array[gridNo][2] + delta) && array[gridNo][2] <= x2) && (y2 < (array[gridNo][3] + delta) && array[gridNo][3] <= y2))

	/*if ((x1 < (array[gridNo][0][0] + delta) && array[gridNo][0][0] <= x1) && (y1 < (array[gridNo][0][1] + delta) && array[gridNo][0][1] <= y1) &&	
             (x2 < (array[gridNo][0][2] + delta) && array[gridNo][0][2] <= x2) && (y2 < (array[gridNo][0][3] + delta) && array[gridNo][0][3] <= y2))*/


           //|| x1 > (array[gridNo][0][0] + delta array[gridNo][0][0] < x1  x1 < (array[gridNo][0][0] + delta
        {
            //std::cout<< "gridNo"<<gridNo<<std::endl;
            //std::cout<<"arrayvalue"<<array[gridNo][0] <<std::endl;
            //std::cout<<"array[gridNo][0] + delta"<<array[gridNo][0] + delta <<std::endl;
            //std::cout<< "x1 "<<x1 <<"y1 "<<y1<<"x2 "<<x2<<"y2 "<<x1<<"y2 "<<x1<<std::endl;
            return true;
	    }

    return false;
}



/*std::vector<Rectangle> defineEnv1()
{
    std::vector<Rectangle> obstacles;
    Rectangle obstacle1;
    obstacle1.x = 5;
    obstacle1.y = 50;
    obstacle1.width = 45;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 300;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 5;
    obstacle3.y = 5;
    obstacle3.width = 395;
    obstacle3.height = 45;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 5;
    obstacle4.y = 350;
    obstacle4.width = 395;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 150;
    obstacle5.y = 200;
    obstacle5.width = 200;
    obstacle5.height = 20;
    obstacles.push_back(obstacle5);
	
    
    return obstacles;
}

std::vector<Rectangle> defineEnv2()
{
    std::vector<Rectangle> obstacles;
    Rectangle obstacle1;
    obstacle1.x = 5;
    obstacle1.y = 50;
    obstacle1.width = 45;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 350;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 5;
    obstacle3.y = 5;
    obstacle3.width = 395;
    obstacle3.height = 45;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 5;
    obstacle4.y = 350;
    obstacle4.width = 395;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 100;
    obstacle5.y = 100;
    obstacle5.width = 100;
    obstacle5.height = 100;
    obstacles.push_back(obstacle5);
	
   
    
    return obstacles;
}*/


// L im the center
std::vector<Rectangle> defineEnv1()
{
    std::vector<Rectangle> obstacles;
    Rectangle obstacle1;
    obstacle1.x = 0;
    obstacle1.y = 50;
    obstacle1.width = 50;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 300;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 0;
    obstacle3.y = 0;
    obstacle3.width = 400;
    obstacle3.height = 50;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 0;
    obstacle4.y = 350;
    obstacle4.width = 400;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 175;
    obstacle5.y = 150;
    obstacle5.width = 100;
    obstacle5.height = 25;
    obstacles.push_back(obstacle5);
	
    Rectangle obstacle6;
    obstacle6.x = 150;
    obstacle6.y = 150;
    obstacle6.width =25;
    obstacle6.height =100;
    obstacles.push_back(obstacle6);
	
    return obstacles;
}

// 2 lines
std::vector<Rectangle> defineEnv2()
{
    std::vector<Rectangle> obstacles;
    Rectangle obstacle1;
    obstacle1.x = 0;
    obstacle1.y = 50;
    obstacle1.width = 50;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 300;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 0;
    obstacle3.y = 0;
    obstacle3.width = 400;
    obstacle3.height = 50;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 0;
    obstacle4.y = 350;
    obstacle4.width = 400;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 200;
    obstacle5.y = 210;
    obstacle5.width = 10;
    obstacle5.height = 140;
    obstacles.push_back(obstacle5);
	
    Rectangle obstacle6;
    obstacle6.x = 200;
    obstacle6.y = 50;
    obstacle6.width =10;
    obstacle6.height =140;
    obstacles.push_back(obstacle6);
	
    return obstacles;
}
// 2 rectangles
std::vector<Rectangle> defineEnv3()
{
    std::vector<Rectangle> obstacles;
    Rectangle obstacle1;
    obstacle1.x = 0;
    obstacle1.y = 50;
    obstacle1.width = 50;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 300;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 0;
    obstacle3.y = 0;
    obstacle3.width = 400;
    obstacle3.height = 50;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 0;
    obstacle4.y = 350;
    obstacle4.width = 400;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 150;
    obstacle5.y = 210;
    obstacle5.width = 100;
    obstacle5.height = 140;
    obstacles.push_back(obstacle5);
	
    Rectangle obstacle6;
    obstacle6.x = 150;
    obstacle6.y = 50;
    obstacle6.width =100;
    obstacle6.height =140;
    obstacles.push_back(obstacle6);
	
    return obstacles;
}

// Digital charlie Brown
std::vector<Rectangle> defineEnv4()
{
    std::vector<Rectangle> obstacles;

    Rectangle obstacle1;
    obstacle1.x = 0;
    obstacle1.y = 50;
    obstacle1.width = 50;
    obstacle1.height = 300;
    obstacles.push_back(obstacle1);
    
    Rectangle obstacle2;
    obstacle2.x = 350;
    obstacle2.y = 50;
    obstacle2.width = 50;
    obstacle2.height = 300;
    obstacles.push_back(obstacle2);

    Rectangle obstacle3;
    obstacle3.x = 0;
    obstacle3.y = 0;
    obstacle3.width = 400;
    obstacle3.height = 50;
    obstacles.push_back(obstacle3);

    Rectangle obstacle4;
    obstacle4.x = 0;
    obstacle4.y = 350;
    obstacle4.width = 400;
    obstacle4.height = 50;
    obstacles.push_back(obstacle4);

    Rectangle obstacle5;
    obstacle5.x = 150;
    obstacle5.y = 250;
    obstacle5.width = 100;
    obstacle5.height = 100;
    obstacles.push_back(obstacle5);
	
    Rectangle obstacle6;
    obstacle6.x = 150;
    obstacle6.y = 50;
    obstacle6.width =100;
    obstacle6.height =100;
    obstacles.push_back(obstacle6);


    Rectangle obstacle7;
    obstacle7.x = 150;
    obstacle7.y = 200;
    obstacle7.width =10;
    obstacle7.height =50;
    obstacles.push_back(obstacle7);

	
    Rectangle obstacle8;
    obstacle8.x = 195;
    obstacle8.y = 200;
    obstacle8.width =10;
    obstacle8.height =50;
    obstacles.push_back(obstacle8);

	
    Rectangle obstacle9;
    obstacle9.x = 240;
    obstacle9.y = 200;
    obstacle9.width =10;
    obstacle9.height =50;
    obstacles.push_back(obstacle9);


	
    Rectangle obstacle10;
    obstacle10.x = 173;
    obstacle10.y = 150;
    obstacle10.width =10;
    obstacle10.height =50;
    obstacles.push_back(obstacle10);

	
    Rectangle obstacle11;
    obstacle11.x = 220;
    obstacle11.y = 150;
    obstacle11.width =10;
    obstacle11.height =50;
    obstacles.push_back(obstacle11);

	
    return obstacles;
}


// digestive system or from file
std::vector<Rectangle> defineEnv5()
{ 
 
    
    std::ifstream fin;
    fin.open("env_mod.txt");
    if (!fin)
    {
        std::cout << "Fatal: Failed to open enviornment " << std::endl;
      
    }

std::vector<Rectangle> obstacles;
    while(!fin.eof())
    {
    // Read the envirnment
    Rectangle obstacle1;
    fin>>obstacle1.x ;
    fin>>obstacle1.y ;
    fin>>obstacle1.width ;
    fin>>obstacle1.height ;
    obstacles.push_back(obstacle1);
	
    }
    
	
    return obstacles;
}



