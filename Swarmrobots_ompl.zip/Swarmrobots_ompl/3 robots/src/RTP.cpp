#include "RTP.h"
#include "ompl/base/goals/GoalSampleableRegion.h"
#include "ompl/tools/config/SelfConfig.h"
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/PlannerData.h>
#include "CollisionChecking.h"
#include <iostream>
#include <fstream>
#include <limits>
#include "Collision.h"

ompl::geometric::RTP::RTP(const base::SpaceInformationPtr &si) : base::Planner(si, "RTP")
{
    specs_.approximateSolutions = true;
}

ompl::geometric::RTP::~RTP()
{
    freeMemory();
}

void ompl::geometric::RTP::clear()
{
    Planner::clear();
    sampler_.reset();
    tree_.clear();
    freeMemory();
}

ompl::base::PlannerStatus ompl::geometric::RTP::solve(const base::PlannerTerminationCondition &ptc)
{
    checkValidity();
    
    // get start and goal states
    base::State* start = pdef_->getStartState(0);
    base::Goal* goal = pdef_->getGoal().get();
    
    // add start state to tree
    base::State* qa = si_->allocState();
    si_->copyState(qa, start);
    tree_.push_back(-1);
    tree_states_.push_back(qa);
    
    // instantiate sampler if none
    if (!sampler_)
    {
        sampler_ = si_->allocStateSampler();
    }
    


   // open the old tree file and copy it to a vector
      
    std::ifstream fin;
    fin.open("file.txt");
    if (!fin)
    {
        std::cout << "Fatal: Failed to open " << std::endl;
        
    }

    // Reading in all configs
    std::vector<Tree> inst;
    while(!fin.eof())
    {
        // Read in the commands
        Tree data;
	fin >> data.tx1;        
	fin >> data.ty1;
	fin >> data.tx1;
	fin >> data.tx2;
        inst.push_back(data);	

	//base::State *tstate = si_->allocState();
	//tstate->as<base::RealVectorStateSpace::StateType>()->values[0] = data.tx1;
	//tstate->as<base::RealVectorStateSpace::StateType>()->values[1] = data.ty1;
	//tstate->as<base::RealVectorStateSpace::StateType>()->values[2] = data.tx1;
	//tstate->as<base::RealVectorStateSpace::StateType>()->values[3] = data.tx2;	
   } 
	bool solved = false;
   	bool approx = false;

    // sample states to find path
    while (!ptc)
    {
        // select random state from tree
        unsigned int qa_idx = rand() % tree_.size();
        base::State* qa = tree_states_[qa_idx];
        
        // sample state from configuration space
        base::State* qb = si_->allocState();
        sampler_->sampleUniform(qb);

        // check path is collision free
        if (si_->checkMotion(qa, qb))
        {
            // add new state to tree
            tree_states_.push_back(qb);
            tree_.push_back(qa_idx);
            
            // break if goal is added to tree
            if (goal->isSatisfied(qb))
            {
                solved = true;
                break;
            }
        }
        // free state if invalid
        else
        { 
            si_->freeState(qb);
        }
    }
    
    
    base::State* end;
    int end_parent;
    
    if (solved)
    {
        end = tree_states_.back();
        end_parent = tree_.back();
    }
    // approximate goal
    else
    {
        approx = true;
        
        // set last point as temp goal
        int closest_idx = tree_.size() - 1;
        double* distance = new double;
        goal->isSatisfied(tree_states_[closest_idx], distance);
        double closest_distance = *distance;
        
        // find state closest to goal
        for (int idx = 0; idx < tree_.size(); idx++)
        {
            goal->isSatisfied(tree_states_[idx], distance);
            if (*distance < closest_distance)
            {
                closest_distance = *distance;
                closest_idx = idx;
            }
        }
        
        end = tree_states_[closest_idx];
        end_parent = tree_[closest_idx];
        delete distance;
    }
    
    // store solution in PathGeometric pointer
    auto path(std::make_shared<PathGeometric>(si_));
    
    // add goal state
    path->append(end);
    int parent_idx = end_parent;
    
    // climb tree by parents to reach start state
    while (parent_idx != -1) 
    {
        // add state to path
        path->append(tree_states_[parent_idx]);
        
        // get parent state
        parent_idx = tree_[parent_idx];
    }
    
    // flip path to go from start to goal
    path->reverse();
    
    // add path to solution
    pdef_->addSolutionPath(path);

    // always returns a solution
    // approx flag if exact goal not reached
    return base::PlannerStatus(true, approx); 
    
}


void ompl::geometric::RTP::getPlannerData(base::PlannerData &data) const
{
    Planner::getPlannerData(data);

    // add goal vertex if it exists
    base::Goal* goal = pdef_->getGoal().get();
    if (goal->isSatisfied(tree_states_.back()))
    {
        data.addGoalVertex(base::PlannerDataVertex(tree_states_.back()));
    }
    
    for (int i = 0; i < tree_.size(); i++) 
    {
        // add start vertex
        if (tree_[i] == -1)
        {
            data.addStartVertex(base::PlannerDataVertex(tree_states_[i]));
        }
        // add edge from parent state to state
        // goal will not be duplicated since it is already added
        else
        {
            data.addEdge(base::PlannerDataVertex(tree_states_[tree_[i]]), base::PlannerDataVertex(tree_states_[i]));
        }
    }
}



void ompl::geometric::RTP::freeMemory()
{
    // free all other states in tree
    for (int i = 0; i < tree_states_.size(); i++)
    {
        si_->freeState(tree_states_[i]);
    }
    tree_states_.clear();
}
