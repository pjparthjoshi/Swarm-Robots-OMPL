#include <iostream>
#include <fstream>
#include <cmath>
#include <functional>
#include <string>
#include <cstdlib>

#include "RTP.h"
#include "RRT.h"
#include "RU.h"
#include "CollisionChecking.h"
#include <ompl/geometric/SimpleSetup.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/spaces/SO2StateSpace.h>
#include <ompl/base/spaces/SE2StateSpace.h>



// This is our state validitiy checker for checking if our point robot is in collision
bool isValidStatePoint(const ompl::base::State* state, const std::vector<Rectangle>& obstacles, ompl::base::RealVectorBounds bounds, int robots)
{
   const ompl::base::RealVectorStateSpace::StateType* r2state;
    r2state = state->as<ompl::base::RealVectorStateSpace::StateType>();
    // Extract x, y
	
     int *x =NULL; 
     x = new int[robots*2];
	
     for(int i=0 ; i< (robots*2);i++)

     { 
	
	*(x + i)= r2state->values[i];
	
     } 

      for(int i=0 ; i< (robots); i++)
      {
		int e =i*2; // even indicator, x
		int o =2*i+1; // odd indicator, y
  
  		if (x[e] > bounds.high[0] || x[e] < bounds.low[0] || x[o] > bounds.high[1] || x[o] < bounds.low[1])
      {		
      
	  return false;
      }  
      
	  return true; //isValidPoint(x, y, x1,y1, obstacles);  	
      }   


 
}


// This is our state validity checker for checking if our square robot is in collision
bool isValidStateSquare(const ompl::base::State* state, double sideLength, const std::vector<Rectangle>& obstacles, ompl::base::RealVectorBounds bounds)
{
    const ompl::base::CompoundState* cstate = state->as<ompl::base::CompoundState>();

    // Extract x, y, theta
    const ompl::base::RealVectorStateSpace::StateType* r2state = cstate->as<ompl::base::RealVectorStateSpace::StateType>(0);
    double x = r2state->values[0];
    double y = r2state->values[1];

    const ompl::base::SO2StateSpace::StateType* so2State = cstate->as<ompl::base::SO2StateSpace::StateType>(1);
    double theta = so2State->value;
    
    // rotate square
    double rot_bl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_bl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    double rot_br_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (-sideLength / 2) + x;
    double rot_br_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (-sideLength / 2) + y;
    double rot_tl_x = std::cos(theta) * (-sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tl_y = std::sin(theta) * (-sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;
    double rot_tr_x = std::cos(theta) * (sideLength / 2) - std::sin(theta) * (sideLength / 2) + x;
    double rot_tr_y = std::sin(theta) * (sideLength / 2) + std::cos(theta) * (sideLength / 2) + y;

    // check bounds
    if (rot_bl_x > bounds.high[0] || rot_bl_x < bounds.low[0] || rot_bl_y > bounds.high[1] || rot_bl_y < bounds.low[1])
    {
        return false;
    }
    if (rot_br_x > bounds.high[0] || rot_br_x < bounds.low[0] || rot_br_y > bounds.high[1] || rot_br_y < bounds.low[1])
    {
        return false;
    }
    if (rot_tl_x > bounds.high[0] || rot_tl_x < bounds.low[0] || rot_tl_y > bounds.high[1] || rot_tl_y < bounds.low[1])
    {
        return false;
    }
    if (rot_tr_x > bounds.high[0] || rot_tr_x < bounds.low[0] || rot_tr_y > bounds.high[1] || rot_tr_y < bounds.low[1])
    {
        return false;
    }

    return isValidSquare(x, y, theta, sideLength, obstacles);
}

void planWithSimpleSetupR4(const std::vector<Rectangle>& obstacles)
{   
    
    std::cout << "Please Enter the robots"<<std::endl;
    int robots;
    std::cin >> robots;


    // set up R4 space
    ompl::base::StateSpacePtr r4(new ompl::base::RealVectorStateSpace(4));
    ompl::base::RealVectorBounds bounds(4);
    bounds.setLow(0); // x and y have a minimum of -2
    bounds.setHigh(400); // x and y have a maximum of 2
    r4->as<ompl::base::RealVectorStateSpace>()->setBounds(bounds);

    // define problem
    ompl::geometric::SimpleSetup ss(r4);
    ss.setStateValidityChecker(std::bind(isValidStatePoint, std::placeholders::_1, obstacles, bounds,robots));

    ompl::base::ScopedState<> start(r4);
    
	int *sx =NULL;
	int dimension = robots*2;
	std::cout<<robots<<" robots"<<std::endl;	
	sx = new int[dimension];	
	
	for(int i=0 ; i< robots; i++)     
	{
	int e =i*2; // even indicator, x
	int o =2*i+1; // odd indicator, y

label1:
	std::cout<<"Please enter your goal states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;


	std::cout<<"Enter x"<< i << "for start:";
	std::cin>>sx[e];
	std::cout<<"Enter y"<< i << "for start:";
	std::cin>>sx[o];


		if (isValidPoint(sx[e],sx[o],obstacles) == false)
		{
			std::cout<<"points collide with obstacles"<<std::endl;
		  	std::cout<< "enter again"<<std::endl;
		  	goto label1;
		}         

		    start[e]= sx[e];
		    start[o]= sx[o];
 	}


    ompl::base::ScopedState<> goal(r4);

    goal[0]= 320;
    goal[1]= 95;
    goal[2]= 320;
    goal[3]= 313;



    ss.setStartAndGoalStates(start, goal);

    ompl::base::PlannerPtr planner(new ompl::geometric::RRT(ss.getSpaceInformation()));
    ss.setPlanner(planner);

    // run solver
    ompl::base::PlannerStatus solved = ss.solve(1.0);

    if (solved)
    {
        // ss.simplifySolution();

        // print the path to screen
        std::cout << "Found solution:" << std::endl;
        ompl::geometric::PathGeometric& path = ss.getSolutionPath();
        path.printAsMatrix(std::cout);

        // print path to file
        std::ofstream fout("path.txt");
        fout << "R4 " << std::endl;
        path.printAsMatrix(fout);
	fout<<goal[0]<<" "<<goal[1]<<" "<<goal[2]<<" "<<goal[3]<<" "<<std::endl;
        fout.close();
		
        std::vector<Tree> tree; // initialization
	
       // Drawgrid(tree);

        // print obstacles to file
        std::ofstream eout("env.txt");
        for (Rectangle rect : obstacles)
        {
            eout << rect.x << " " << rect.y << " " << rect.width << " " << rect.height << " " << std::endl;
        }
        eout.close();
    }
    else
        std::cout << "No solution found" << std::endl;
}


void ReuseRRT(const std::vector<Rectangle>& obstacles)
{


     int *pointer =NULL;
    std::cout << "Please Enter the robots"<<std::endl;
    int robots;
    std::cin >> robots;
    pointer = new int[robots];
    // set up R4 space
    ompl::base::StateSpacePtr r4(new ompl::base::RealVectorStateSpace(4));
    ompl::base::RealVectorBounds bounds(4);
    bounds.setLow(0); // x and y have a minimum of -2
    bounds.setHigh(400); // x and y have a maximum of 2
    r4->as<ompl::base::RealVectorStateSpace>()->setBounds(bounds);

    // define problem
    ompl::geometric::SimpleSetup ss(r4);
    ss.setStateValidityChecker(std::bind(isValidStatePoint, std::placeholders::_1, obstacles, bounds,robots));

    ompl::base::ScopedState<> start(r4);
    start[0] = 254;
    start[1] = 438;
    start[2] = 333;
    start[3] = 410;

    ompl::base::ScopedState<> goal(r4);


label:
	std::cout<<"Please enter your goal states for x ranges from 55 to 345 and y ranges from 55 to 345"<< std::endl;
	int x1,y1,x2,y2;
    
	std::cout<<"Enter x1 for goal:";
	std::cin>>x1;
	std::cout<<"Enter y1 for goal:";
	std::cin>>y1;
	std::cout<<"Enter x2 for goal:";
	std::cin>>x2;
	std::cout<<"Enter y2 for goal:";
	std::cin>>y2;


        if ( isValidPoint(x1,y1,obstacles) == false || isValidPoint(x2,y2,obstacles) == false)
	{
		std::cout<<"points collide with obstacles"<<std::endl;
	  	std::cout<< "enter again"<<std::endl;
	  	goto label;
	}         

	    goal[0]= x1;
	    goal[1]= y1;
	    goal[2]= x2;
    	    goal[3]= y2;

  /*goal[0]= 89;
    goal[1]= 81;
    goal[2]= 268;
    goal[3]= 256;

    goal[0]= 320;
    goal[1]= 95;
    goal[2]= 320;
    goal[3]= 313;*/

    ss.setStartAndGoalStates(start, goal);

    ompl::base::PlannerPtr planner(new ompl::geometric::RU(ss.getSpaceInformation()));
    ss.setPlanner(planner);

    // run solver
    ompl::base::PlannerStatus solved = ss.solve(1.0);

    if (solved)
    {
        // ss.simplifySolution();

        // print the path to screen
        std::cout << "Found solution:" << std::endl;
        ompl::geometric::PathGeometric& path = ss.getSolutionPath();
        path.printAsMatrix(std::cout);

        // print path to file
        std::ofstream fout("path.txt");
        fout << "R4" << std::endl;
        path.printAsMatrix(fout);
	fout<<goal[0]<<" "<<goal[1]<<" "<<goal[2]<<" "<<goal[3]<<" "<<std::endl;
        fout.close();
		
        //std::vector<Tree> tree; // initialization
	
        //Drawgrid(tree);

        // print obstacles to file
        std::ofstream eout("env.txt");
        for (Rectangle rect : obstacles)
        {
            eout << rect.x << " " << rect.y << " " << rect.width << " " << rect.height << " " << std::endl;
        }
        eout.close();
    }
    else
        std::cout << "No solution found" << std::endl;
}


int main(int, char **)
{
    std::vector<Rectangle> obstacles;

    // select robot
    int robot;
    do
    {
        std::cout << "Plan for: "<< std::endl;
        std::cout << " (1) 2 point robot in 2D" << std::endl;
        std::cout << " (2) Reuse the old RRT Tree" << std::endl;

        std::cin >> robot;
    } while (robot < 1 || robot > 2);
    
    // select environment
    int env;
    do
    {
        std::cout << "In environment 1 , 2 ,3 4,5: "<< std::endl;

        std::cin >> env;
    } while (env < 1 || env > 5);

    // create environment
    switch(env)
    {
    case 1:
        obstacles = defineEnv1();
        break;
    case 2:
        obstacles = defineEnv2();
        break;    
    case 3:
        obstacles = defineEnv3();
        break;    
    case 4:
        obstacles = defineEnv4();
        break;    
    case 5:
        obstacles = defineEnv5();
        break;
     
    }

   

    // plan path
    switch(robot)
    {
    case 1:
        planWithSimpleSetupR4(obstacles);
        break;
    case 2:
        ReuseRRT(obstacles);
        break;
    }
    
    return 0;
}
