#include <ompl/geometric/planners/PlannerIncludes.h>

namespace ompl
{
    namespace geometric
    {
        class RU : public base::Planner
        {
        public:
            RU(const base::SpaceInformationPtr &si);

            ~RU() override;

            void getPlannerData(base::PlannerData &data) const override;
	    
            base::PlannerStatus solve(const base::PlannerTerminationCondition &ptc) override;

            void clear() override;

        protected:
            void freeMemory();

            // vector containing parent states
            // of corresponding state in tree_states
            std::vector<int> tree_;

            // vector of configuration states in tree
            std::vector<base::State*> tree_states_;
	    std::vector<base::State*> parent_states_;

        };
    }
}

