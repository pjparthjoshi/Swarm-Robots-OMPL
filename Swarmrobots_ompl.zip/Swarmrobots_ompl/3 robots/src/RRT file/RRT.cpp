#include "RRT.h"
#include "ompl/base/goals/GoalSampleableRegion.h"
#include "ompl/tools/config/SelfConfig.h"
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/base/PlannerData.h>
#include "CollisionChecking.h"
#include <iostream>
#include <fstream>
#include <limits>
#include "Collision.h"

int robots;

ompl::geometric::RRT::RRT(const base::SpaceInformationPtr &si) : base::Planner(si, "RRT")
{
    specs_.approximateSolutions = true;
    specs_.directed = true;
    Planner::declareParam<double>("range", this, &RRT::setRange, &RRT::getRange, "0.:1.:10000.");
    //Planner::declareParam<double>("goal_bias", this, &RRT::setGoalBias, &RRT::getGoalBias, "0.:.05:1.");
}

ompl::geometric::RRT::~RRT()
{
    freeMemory();
}

void ompl::geometric::RRT::clear()
{
    Planner::clear();
    sampler_.reset();
    freeMemory();
    if (nn_)
        nn_->clear();
    lastGoalMotion_ = nullptr;
}

void ompl::geometric::RRT::setup()
{
    Planner::setup();
    tools::SelfConfig sc(si_, getName());
    sc.configurePlannerRange(maxDistance_);

    if (!nn_)
        nn_.reset(tools::SelfConfig::getDefaultNearestNeighbors<Motion *>(this));
    nn_->setDistanceFunction([this](const Motion *a, const Motion *b)
                             {
                                 return distanceFunction(a, b);
                             });
}

void ompl::geometric::RRT::freeMemory()
{
    if (nn_)
    {
        std::vector<Motion *> motions;
        nn_->list(motions);
        for (auto &motion : motions)
        {
            if (motion->state != nullptr)
                si_->freeState(motion->state);
            delete motion;
        }
    }
}

std::vector<Tree> tree; // vector to store tree #############################################################################################

ompl::base::PlannerStatus ompl::geometric::RRT::solve(const base::PlannerTerminationCondition &ptc)
{
    checkValidity(); // check the planner which is called is working, setup is called ,goal is set etc
    base::Goal *goal = pdef_->getGoal().get(); // fetch goal values
    auto *goal_s = dynamic_cast<base::GoalSampleableRegion *>(goal);

// clear every thing from the file generating tree

	std::ofstream file;
	file.open("file.txt",std::ios::trunc);	 
	
        file<<"New data"<<std::endl;
	file.close();

    while (const base::State *st = pis_.nextStart()) 
    {
        auto *motion = new Motion(si_);
        si_->copyState(motion->state, st); // copy start points
        nn_->add(motion);
    }

    if (nn_->size() == 0)
    {
        OMPL_ERROR("%s: There are no valid initial states!", getName().c_str());
        return base::PlannerStatus::INVALID_START;
    }

    if (!sampler_)
        sampler_ = si_->allocStateSampler();

    OMPL_INFORM("%s: Starting planning with %u states already in datastructure", getName().c_str(), nn_->size());

    Motion *solution = nullptr;
    Motion *approxsol = nullptr;
    double approxdif = std::numeric_limits<double>::infinity();
    auto *rmotion = new Motion(si_);
    base::State *rstate = rmotion->state;
    base::State *xstate = si_->allocState();



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*Task:


        1) pick a random config in R^4
        2) look at your RRT nodes, pick the closest (minimum norm) node to the random config.
        3) Try moves in 8 directions (every 45 degrees).  Compute what happens to the two robots if the move is applied (if one robot hits an obstacle, the obstacle should stop that robot's movement into the obstacle).  For all 8 movements, pick the one that has the minimum norm distance to the random config from step 1
        repeat.
*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    while (!ptc)
    {
        /* sample random state (with goal biasing) */
        //if ((goal_s != nullptr) && rng_.uniform01() < goalBias_ && goal_s->canSample())
            //goal_s->sampleGoal(rstate);
        //else
          
	
	/* find closest state in the tree */
         Motion *nmotion = nn_->nearest(rmotion); // rmotion randomly sampled point, nmotion is the nearest in the nn data structure
         base::State *dstate = rstate; // 
        //si_->printState(rstate,std::cout);// print random state

	//unsigned int dimension = si_->getStateDimension();
	//std::cout<<dimension<<std::endl;
        
		
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Point 3


/*
Given Randomly sampled state generated (r1x,r1y,r2x,r2y) , nearest node(ax,ay,bx,by) in the tree for that sample

    mindist = infinity;
    bestAngle = 1;
    angles = [0,45,90,135,180,225,270,315];
    movedist = 10;  //or some other smaller distance (steps)
    for i = 1:8
          (cx,cy,dx,dy) = ApplyMove( (ax,ay,bx,by) , movedist, angles(i) )// next point
          if calcDistance( (cx,cy,dx,dy),  (r1x,r1y,r2x,r2y) ) < mindist
                      mindist = calcDistance( (cx,cy,dx,dy),  (r1x,r1y,r2x,r2y) )
                      bestAngle = i
          end
    end
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////       
       
	         		

				base::State *q_near_proj = si_->allocState();// allocate memory
				base::State *q_rand_proj = si_->allocState();// allocate memory


			int dim_in = 0;
		for (unsigned int n = 0; n < robots*2; n++) {
			q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[n] = 
				nmotion->state->as<base::RealVectorStateSpace::StateType>()->values[dim_in];
			q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[n] = 
				rstate->as<base::RealVectorStateSpace::StateType>()->values[dim_in];


			//std::cout<< q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[n]<<" qnear  qrand "<<q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[n] << std::endl;	
			dim_in++;
		}   


			double *q_n = NULL;
			double *rand_value = NULL;
			double *qnew_value = NULL;
			double *qrobot = NULL;			
			q_n = new double[robots*2];
			rand_value = new double[robots*2];
			qnew_value = new double[robots*2];
			qrobot = new double[robots*2];

			
                        
			for(int i=0 ; i< (robots*2);i++){ 
	
				*(q_n + i)= q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[i];
				*(qrobot + i)= q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[i];				
				*(rand_value + i)= q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[i];	
	
			}
				
				/*double r1x=q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[0];
				double r1y=q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[1];
				double r2x=q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[2];
				double r2y=q_near_proj->as<base::RealVectorStateSpace::StateType>()->values[3];

                              	//std::cout<<" r1x "<<r1x<<" "<<r1y<<" "<<r2x<<" "<<r2y<<" "<<std::endl;
				double ax=q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[0];
				double ay=q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[1];
				double bx=q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[2];
				double by=q_rand_proj->as<base::RealVectorStateSpace::StateType>()->values[3];
				//std::cout<<"ax"<<ax<<" "<<ay<<" "<<bx<<" "<<by<<" "<<std::endl;*/
				
				 
		                    si_->freeState(q_near_proj);
				    si_->freeState(q_rand_proj);

	 			    double min_dist =std::numeric_limits<double>::infinity();
				    int bestAngle_idx = 1;
				    double angles[16] = {0,45,90,135,180,225,270,315,22.5,67.5,112.5,157.5,202.5,247.5,292.5,337.5};
				    double movedist = 5;
				    double movedist1 =1*movedist; // we some angles we check at higher angles 
		                        
                               //double rand_value[4]={ax,ay,bx,by};
			      
			 //for(int s=0; s < sizeof(angles); s++){
    			 //std::cout << angles[s] << std::endl;
			 //}
		
		std::cout<<"q_n"<<q_n[0]<<"qrobot"<<qrobot[0]<<"rand_value"<<rand_value[0]<< std::endl;

			
 		    for(int i=0;i<16;i++){

				int e =i*2; // even indicator, x
				int o =2*i+1; // odd indicator, y
				double temp1[2];
				
			if (i<8)
				{

				for (int a1 ; a1< robots ;a1++)
				
				{
				int e1 =a1*2; // even indicator, x
				int o1 =2*a1+1; // odd indicator, y			
				Nextpoint(q_n[e1],q_n[o1],movedist,angles[i],temp1);
				qnew_value[e]= *temp1;
				qnew_value[o]= *(temp1+1);
				}

				}

			else{
				
				for (int a2 ; a2< robots ;a2++)
				
				{
				int e2 =a2*2; // even indicator, x
				int o2 =2*a2+1; // odd indicator, y			
				Nextpoint(q_n[e2],q_n[o2],movedist1,angles[i],temp1);
				qnew_value[e]= *temp1;
				qnew_value[o]= *(temp1+1);
				}
				
		         }	

				if (calcDistance(qnew_value,rand_value) < min_dist){      // error here : Segmentation fault , (core dump) as was using pointer variable;;; solved
				        min_dist = calcDistance(qnew_value,rand_value);
					bestAngle_idx=i;							
			       	}
	           }     


				 double best_angle = angles[bestAngle_idx];
                                 //std::cout<<"min_dist= "<<min_dist<<std::endl;                  			
				 //std::cout<<"best angle= "<<best_angle<<std::endl;
				
				 //Robot * Robo = new Robot[robots];
				 //MoveRobot * Move = new MoveRobot[robots];
				 double Movex1=0;
				 double Movey1=0;

				 double Robotradius =0.2;

				 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// after finding best angle and distance, move robot.Also, Stop the individual Robot if it is colliding with any obstacle 

			std::vector<Rectangle> obstacles; // initialization
			
			obstacles = defineEnv3();
			
			for(int count; count < robots ; count++)
			{

				int ex =count*2; // even indicator, x
				int oy =2*count+1; // odd indicator, y

			        double r1[2];
			
		                Nextpoint(qrobot[ex],qrobot[oy],movedist,best_angle,r1);

		                Movex1=qrobot[ex];
		                Movey1=qrobot[oy];
		                qrobot[ex]= *r1;
		                qrobot[oy]= *(r1+1);
		                //std::cout<<Robot1.x<<"--Robot1--"<<Robot1.y<<std::endl;

	                    if (isValidPoint(qrobot[ex],qrobot[oy],obstacles)==true)// or isvalidpoint

	                            {  
	                                Movex1=0;
	                                Movey1=0;
	                                
	                            }else{

				int step=0;
				while(isValidPoint(qrobot[ex],qrobot[oy],obstacles)==false && (step < movedist-2))
				  {
	                                //std::cout<<"i "<<i<<"move dist"<<movedist<<"Robot1.x "<<Robot1.x<<"Robot1.y " <<Robot1.y<<std::endl;
					  step=step+1;
					  qrobot[ex]= qrobot[ex] + (step/movedist)*(Movex1-q_n[ex]);
	                                  qrobot[oy]= qrobot[oy] + (step/movedist)*(Movey1-q_n[oy]);					  
				
					
				   }
	                         	if (isValidPoint(qrobot[ex],qrobot[oy],obstacles)==false)
					{

					  qrobot[ex]= Movex1;
	                                  qrobot[oy]= Movey1;					  

	                                  Movex1=0;
	                                  Movey1=0;}

	                            }

		  }

                         


//std::cout<<"done"<<std::endl;


//std::cout<<Robot1.x<<" robot "<<Robot1.y<<" "<<Robot2.x<<" "<<Robot2.y<<" "<<std::endl;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// projectback to state        

	   int dim_out=0;  
                
           for (unsigned int d = 0; d < robots*2; d++) {
			xstate->as<base::RealVectorStateSpace::StateType>()->values[d] = qrobot[dim_out++];
			dim_out++;
			
	 	}


				//std::cout<<xstate->as<base::RealVectorStateSpace::StateType>()->values[0]<<" robot "<<xstate->as<base::RealVectorStateSpace::StateType>()->values[1]<<" "<<xstate->as<base::RealVectorStateSpace::StateType>()->values[2]<<" "<<xstate->as<base::RealVectorStateSpace::StateType>()->values[3]<<" "<<std::endl;
		




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//old Part to be deleted

        /* find state to add */
       /*  int  d = si_->distance(nmotion->state, rstate); // if the distance between randomly sampled state and the nearest state in the tree is larger than the decided distance, interpolate find xstate
        if (d > maxDistance_)
        {
            si_->getStateSpace()->interpolate(nmotion->state, rstate, maxDistance_ / d, xstate);
            dstate = xstate;   // dstate can be xstate(if d is large) or rstate(if d is not large)
	    
        }*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	dstate = xstate; 

	bool flag = true;
		
	for(int i ; i< robots ; i++)
	{

	int ex =i*2; // even indicator, x
	int oy =2*i+1; // odd indicator, y
	

	       if (q_n[ex]== qrobot[ex] || q_n[oy]== qrobot[oy] )
		    {
		     if ( isValidPath(q_n[ex],q_n[oy],qrobot[ex],qrobot[oy],obstacles)==false)
			{
				flag = false;
			}


		   }
	}


			if (si_->checkMotion(nmotion->state, dstate) && flag ==true )

			{
				std::ofstream file;
				file.open("file.txt",std::ios::app);	// append mode	



				for(int i1 ; i1< robots*2 ; i1++)
				{

				file<<q_n[i1]<<" ";
				}
				file<<std::endl;

				//file.close();
				//file.open("file.txt",std::ios::app);	

				for(int i2 ; i2< robots*2 ; i2++)
				{

				file<<qrobot[i2]<<" ";
				}
				file<<std::endl;

				file.close();

		
				/* Store the tree in a vector*/

				/*Tree node1;
				node1.tx1 = r1x;
				node1.ty1 = r1y;
				node1.tx2 = r2x;
				node1.ty2 = r2y;
				tree.push_back(node1);

				Tree node2;
				node2.tx1 = Robot1.x;
				node2.ty1 = Robot1.y;
				node2.tx2 = Robot2.x;
				node2.ty2 = Robot2.y;
				tree.push_back(node2);*/
			      
				
			 /* create a motion */
			    auto *motion = new Motion(si_);
			    si_->copyState(motion->state, dstate);
			    motion->parent = nmotion;
			    


			    nn_->add(motion);
			    double dist = 0.0;
			    bool sat = goal->isSatisfied(motion->state, &dist);
			    if (sat)
			    {
				approxdif = dist;
				solution = motion;
				break;
			    }
			    if (dist < approxdif)
			    {
				approxdif = dist;
				approxsol = motion;
			    }
	
	      	   
	    	  
                 } 



			delete q_n ;
			delete rand_value;
			delete qnew_value;
			delete qrobot;	

    }

     

    bool solved = false;
    bool approximate = false;
    if (solution == nullptr)
    {
        solution = approxsol;
        approximate = true;
    }

    if (solution != nullptr)
    {
        lastGoalMotion_ = solution;

        /* construct the solution path */
        std::vector<Motion *> mpath;
        while (solution != nullptr)
        {
            mpath.push_back(solution);
            solution = solution->parent;
        }

        /* set the solution path */
        auto path(std::make_shared<PathGeometric>(si_));
        for (int i = mpath.size() - 1; i >= 0; --i)
            path->append(mpath[i]->state);
        pdef_->addSolutionPath(path, approximate, approxdif, getName());
        solved = true;
	
    }

    si_->freeState(xstate);
    if (rmotion->state != nullptr)
        si_->freeState(rmotion->state);
    delete rmotion;

    OMPL_INFORM("%s: Created %u states", getName().c_str(), nn_->size());

    return base::PlannerStatus(solved, approximate);
}

std::vector<Tree> calltree()
{
 return tree;
 
}

void ompl::geometric::RRT::getPlannerData(base::PlannerData &data) const
{
    Planner::getPlannerData(data);

    std::vector<Motion *> motions;
    if (nn_)
        nn_->list(motions);       
	
    if (lastGoalMotion_ != nullptr)
        data.addGoalVertex(base::PlannerDataVertex(lastGoalMotion_->state));

    for (auto &motion : motions)
    {
        if (motion->parent == nullptr)
            data.addStartVertex(base::PlannerDataVertex(motion->state));
        else
            data.addEdge(base::PlannerDataVertex(motion->parent->state), base::PlannerDataVertex(motion->state));
    }
}


